package com.example.womensecurityapp.services;

import android.content.Context;
import android.widget.Toast;

public class background_location_update {

    public void update_location(Context context)
    {
        Toast.makeText(context,"update",Toast.LENGTH_LONG).show();
    }
}
